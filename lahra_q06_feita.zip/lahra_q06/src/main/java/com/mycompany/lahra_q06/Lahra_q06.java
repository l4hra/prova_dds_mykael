/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_q06;

import java.util.Scanner;

/**
 *
 * @author lnunes
 */
public class Lahra_q06 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int n;
        
        System.out.println("Digite um numero");
        n =  ler.nextInt();
        
        int media = (n / n) * 2;
        int soma = (n / n) +2 ;
        
        System.out.println("A media deste numero é : "+ media);
        System.out.println("A soma deste numero é : "+ soma);
    }
}
