/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_q08;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author lnunes
 */
public class Lahra_q08 {

    public static void main(String[] args) throws IOException {
        
        Scanner ler = new Scanner(System.in);

        System.out.println("Digite um numero inteiro");
        int n = ler.nextInt();
        
       FileWriter arquivo = new FileWriter("D:\\Users\\lnunes\\Desktop\\TABUADA.txt");
       PrintWriter escrever = new PrintWriter(arquivo);
       
       escrever.println("---- TABUADA DE ----");
       escrever.println(n + "x 1 = " + (n*1));
       escrever.println(n + "x 2 = " + (n*2));
       escrever.println(n + "x 3 = " + (n*3));
       escrever.println(n + "x 4 = " + (n*4));
       escrever.println(n + "x 5 = " + (n*5));
       escrever.println(n + "x 6 = " + (n*6));
       escrever.println(n + "x 7 = " + (n*7));
       escrever.println(n + "x 9 = " + (n*8));
       escrever.println(n + "x 9 = " + (n*9));
       escrever.println(n + "x 10 = " +(n*10));
       
       arquivo.close();
    }
}
