/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_q02;

import java.util.Scanner;

/**
 *
 * @author lnunes
 */
public class Lahra_q02 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int idade;
        int mes;
        int ano;
        int dias;
        
        System.out.println("Quantos anos você tem?");
        idade = ler.nextInt();
        
        System.out.println("Qual o mês do seu aniversario (represente em numeros)?");
        mes = ler.nextInt();
        
      
         System.out.println("Qual o dia do seu aniversario (represente em numeros)?");
         dias = ler.nextInt();
         
         int totalano = (idade * 365);
         int totaldias = (30 * mes);
         System.out.println(idade + " anos "+ mes + " meses " + totaldias +" dias = " + (totaldias + totalano) );
    }
}
