/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_q07;

import java.util.Scanner;

/**
 *
 * @author lnunes
 */
public class Lahra_q07 {

    public static void main(String[] args) {
       Scanner ler = new Scanner(System.in); 
       
       String tent2;
        System.out.println("---- Qual o filme? ----");
        
        System.out.print("Digite seu nome jogador 1 : ");
        String j1 = ler.nextLine();
        
        System.out.println( j1 + " digite o nome do filme: ");
        String filme1 = ler.nextLine();
        
       System.out.println( j1 + " digite a sua pista: ");
        String pista1 = ler.nextLine(); 
        
       System.out.println( j1 + " digite a sua segunda pista: ");
        String pista2 = ler.nextLine(); 
        
        System.out.println("Digite seu nome jogador 2 :");
        String j2 = ler.nextLine(); 
       
       System.out.println( j2 + " A pista 1 é :" + pista1);
       System.out.println( j2 + " Qual o nome do filme?");
        String tent1 = ler.nextLine();  
        
        
        if(filme1.equalsIgnoreCase(filme1) != tent1.equalsIgnoreCase(tent1)){
      System.out.println( j2 + " VOCÊ ERROU!!");  
     
       
      
        }
         System.out.println( j2 + " A pista 2 é :" + pista2); 
         System.out.println( j2 + " Qual o nome do filme?");
      tent2 = ler.nextLine(); 
      
        if(filme1.equalsIgnoreCase(filme1) != tent2.equalsIgnoreCase(tent1)){
        System.out.print( j2 + " VOCÊ ERROU!!");  
        }else if(filme1.equalsIgnoreCase(filme1) == tent1.equalsIgnoreCase(tent1)){
     System.out.print( j2 + " VOCÊ ACERTOU!!");              
    }else if(filme1.equalsIgnoreCase(filme1) == tent2.equalsIgnoreCase(tent2)){
        System.out.print( j2 + " VOCÊ ACERTOU!!");    
    }
           
    }
}
