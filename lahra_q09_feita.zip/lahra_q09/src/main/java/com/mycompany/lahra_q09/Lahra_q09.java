/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_q09;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author lnunes
 */
public class Lahra_q09 {

    public static void main(String[] args) throws IOException {
      Scanner ler = new Scanner(System.in);    
      String categoria;
      
        System.out.println("Digite seu nome: ");
        String nome = ler.nextLine();
        
      System.out.println("Digite seu peso: ");
      float peso = ler.nextFloat();   
      
      if(peso < 65){
      categoria = "pena";               
      }else if(peso >= 65 && peso < 72){
       categoria = "leve";
      }else if(peso >= 72 && peso < 79){
       categoria = "ligeiro";
      }else if(peso >= 79 && peso < 86){
       categoria = "meio médio";
      }else if(peso >= 86 && peso < 93){
       categoria = "médio";
      }else if(peso >= 93 && peso < 100){
       categoria = "meio pesado";
      }else{
          categoria ="pesado";
      }
      
     FileWriter arquivo = new FileWriter("D:\\Users\\lnunes\\Desktop\\Lutador.txt");
     PrintWriter escrever = new PrintWriter(arquivo);
     
     escrever.println(" O lutador " + nome + "pesa: " + peso+ "e se enquadra na categoria : " + categoria);   
    }
}
