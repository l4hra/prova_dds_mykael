/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_q04;

import javax.swing.JOptionPane;

/**
 *
 * @author lnunes
 */
public class Lahra_q04 {

    public static void main(String[] args) {
        
      String inpu1 = JOptionPane.showInputDialog("Digite um numero inteiro: ");
      int valor = Integer.parseInt(inpu1);
      
     int antecessor = valor - 1;
     int sucessor = valor + 1;
     
     JOptionPane.showMessageDialog(null, "o antecessor de " +valor+ " é " + antecessor +" e o sucessor é " + sucessor);
    }
}
